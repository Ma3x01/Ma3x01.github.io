// Данные о прокате фильмов
const moviesData = [
    { title: "Дюна. Часть вторая.", duration: "2 ч. 46 мин.", genre: "Фантастика, боевик, драма, приключения.", image: "../img/Dune_PartTwo.jpg" },
    { title: "Оппенгеймер.", duration: "3 ч. 00 мин.", genre: "Драма, биография, история.", image: "../img/Oppenheimer.jpg" },
    { title: "Пчеловод.", duration: "1 ч. 45 мин.", genre: "Боевик, криминал.", image: "../img/TheBeekeeper.jpg" },
    { title: "Пять ночей с Фредди.", duration: "1 ч. 49 мин.", genre: "Ужасы, драма.", image: "../img/FiveNightsAtFreddi.jpeg" },
    { title: "След киллера.", duration: "1 ч. 37 мин.", genre: "Боевик, триллер, драма, криминал, детектив.", image: "../img/Damaged.jpg" },
    { title: "Остров изгоев.", duration: "1 ч. 53 мин.", genre: "Триллер, драма.", image: "../img/SoudainSeuls.jpg" }
];

// Функция для загрузки и рендеринга данных о фильмах
function renderMovies() {
    const template = document.getElementById('movies-template').innerHTML;
    const rendered = Mustache.render(template, { movies: moviesData });
    document.getElementById('movies-list').innerHTML = rendered;
}

// Загружаем данные и рендерим фильмы при загрузке страницы
window.onload = function() {
    renderMovies();
};
